document.getElementById("dateupdate").innerHTML =
  "This page was last modified on: " + document.lastModified;
